#define SHORT_ADDRESSES 0

#undef SHORT_INTS

#undef SHORT_SPACE

#define FUNCTION_ADRESSES 0

#define ALIGN_LONGS 1

#undef LOW_ABSMI

#define MSHIFTOFFS 1

#define HAVE_SIGNAL 1

#define UInt unsigned int
#define UShort unsigned short
#define Int int

#define FFIEEE 1

#define Float float
#define FAFloat double


#define FunAdr(X) X

#define MIPSEL 

#define HAVE_PROTO 1


