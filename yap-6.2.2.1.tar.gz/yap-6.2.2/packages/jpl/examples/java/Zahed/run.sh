#!/bin/sh

. ../env.sh

run Zahed

