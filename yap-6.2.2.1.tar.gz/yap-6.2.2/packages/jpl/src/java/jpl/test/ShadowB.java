/*
 * Created on 22-Nov-2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package jpl.test;


public class ShadowB extends ShadowA {
	public String	shadow;
	public ShadowB(String s) {
		shadow = s;
	}
	public static int fieldStaticInt;
}