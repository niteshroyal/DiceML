/*
 * Created on 22-Nov-2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package jpl.test;


public class ShadowA {
	public int	shadow	= -1;
	public static int fieldStaticInt;
}