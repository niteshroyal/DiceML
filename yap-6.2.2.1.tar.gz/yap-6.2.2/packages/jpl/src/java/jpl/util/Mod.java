package jpl.util;

public class Mod
	{
	public static void main(String args[])
		{

		System.out.println( " 17 %  5 = " + ( 17 %  5));
		System.out.println( " 17 % -5 = " + ( 17 % -5));
		System.out.println( "-17 %  5 = " + (-17 %  5));
		System.out.println( "-17 % -5 = " + (-17 % -5));
		while (true)
			;
		}
	}

