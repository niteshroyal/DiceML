// $Id$
package jpl;

class Version {
	public final int    major            = 3;
	public final int	minor	= 1;
	public final int    patch            = 4;
	public final String status           = "alpha";
}
